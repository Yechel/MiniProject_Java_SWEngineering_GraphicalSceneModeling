package Geometrics;

import Primitives.Point3D;
import Primitives.Vector;

public class Cylinder extends RadialGeometry {
    private Point3D _axisPoint;
    private Vector _axisDirection;


    public Point3D get_axisPoint() {
        return _axisPoint;
    }

    public Vector get_axisDirection() {
        return _axisDirection;
    }

    public void set_axisPoint(Point3D _axisPoint) {
        this._axisPoint = _axisPoint;
    }


    public void set_axisDirection(Vector _axisDirection) {
        this._axisDirection = _axisDirection;
    }

    public Cylinder() {
        super();
        set_axisDirection(new Vector(head));
        set_axisPoint(new Point3D(z));
    }

    public Cylinder(Point3D axisPoint, Vector axisDirection, double radius) {
        super(radius);
        set_axisDirection(axisDirection);
        set_axisPoint(axisPoint);
    }


    @Override
    public boolean equals(Object obj) throws Exception {
        if (obj instanceof Cylinder) {
            if (get_axisDirection() == ((Cylinder) obj).get_axisDirection())
                if (get_axisPoint() == ((Cylinder) obj).get_axisPoint())/*TODO: fix that comapre to any point in the normal vector*/
                    if (get_radius() == ((Cylinder) obj).get_radius()) return true;
        }
        throw new Exception("the object is not Cylinder type");
    }

    @Override
    public String toString() {
        return String.format("Cylinder: r=%s, center=%s, direction=%s.", get_radius(), get_axisPoint(), get_axisDirection());
        //TODO: fix the center to normal vector
    }
}
