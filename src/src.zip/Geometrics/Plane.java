package Geometrics;

import Primitives.Point3D;
import Primitives.Vector;

import static java.lang.String.format;

public class Plane {
    private Point3D _p1;
    private Point3D _p2;
    private Point3D _p3;

    /*constractors*/
    public Plane(Point3D p1, Point3D p2, Point3D p3) throws Exception {
        if (p1.inSameLine(p2,p3)) {
            throw new Exception("Plane Exeption: the points are in the same line");
        }
        set_p1(p1);
        set_p2(p2);
        set_p3(p3);
    }
    public Plane() {
        set_p1(new Point3D());
        set_p2(new Point3D());
        set_p3(new Point3D());
    }

    /*getters*/

    public Point3D get_p1() {
        return _p1;
    }

    public Point3D get_p2() {
        return _p2;
    }

    public Point3D get_p3() {
        return _p3;
    }

    /*setters*/
    public void set_p1(Point3D _p1) {
        this._p1 = _p1;
    }

    public void set_p2(Point3D _p2) {
        this._p2 = _p2;
    }

    public void set_p3(Point3D _p3) {
        this._p3 = _p3;
    }

    //TODO: throw exeptions
    @Override
    public boolean equals(Object obj)  {
        if (obj instanceof Plane) { //Palanes are equal if they parallel and the they had the sme normalize vector
            return (_p1 == ((Plane) obj).get_p1()); //TODO:correct that function
        }
        return false;
    }

    @Override
    public String toString() {
        return format("Plane that expands from P1:%s, P2:%s, P3:%s",
                get_p1().toString(),
                get_p2().toString(),
                get_p3().toString());
    }



}
