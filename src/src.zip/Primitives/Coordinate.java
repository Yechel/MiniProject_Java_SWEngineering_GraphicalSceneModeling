package Primitives;

public class Coordinate {
    private double _coordinate;

    //getter
    public double get_coordinate() {
        return _coordinate;
    }

    //setter
    public void set_coordinate(double _coordinate) {
        this._coordinate = _coordinate;
    }

    //ctors
    public Coordinate() {
        set_coordinate(0);
    }

    public Coordinate(double d) {
        set_coordinate(d);
    }


    @Override
    public boolean equals(Object obj) throws ExceptionInInitializerError {
        if (obj instanceof Coordinate) {
            return get_coordinate() == ((Coordinate) obj).get_coordinate();
        }
        throw new ExceptionInInitializerError("the object is not Cylinder type");
    }

    @Override
    public String toString() {
        return String.format("%s", get_coordinate());
    }

    public Coordinate mult(double d) {
        return new Coordinate(get_coordinate()*d);
    }
}
