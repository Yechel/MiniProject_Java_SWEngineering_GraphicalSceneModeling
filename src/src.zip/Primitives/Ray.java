package Primitives;

public class Ray {
    private Point3D _POO;
    private Vector _direction;


}
