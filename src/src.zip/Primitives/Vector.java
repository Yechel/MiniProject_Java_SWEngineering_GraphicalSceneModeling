package Primitives;

import java.math.MathContext;

public class Vector {
    private Point3D _head;

    public Point3D get_head() {
        return _head;
    }

    public void set_head(Point3D _head) {
        this._head = new Point3D(_head);
    }

    public Vector(Point3D head) {
        set_head(head);
    }

    //methods

    public double length(Vector v) {

        return Math.sqrt(Math.pow(v.get_head().get_x().get_coordinate(), 2) +
                Math.pow(v.get_head().get_y().get_coordinate(), 2) +
                Math.pow(v.get_head().get_z().get_coordinate(), 2));
    }

//TODO:imp
    public Vector crossProduct (Vector v1, Vector v2)
    {
        v2.get_head().get_x()*v1.get_head().get_x()*


    }

    public Vector normalize() {
        return this.scale(1/length(this));
    }

    // TODO: see where to put this
    public Vector getNormal(Point3D point) {
        Vector U = new Vector(_p1, _p2);
        Vector V = new Vector(_p1, _p3);
        Vector N = new Vector(U.crossProduct(V));
        N.normalize();
        N.scale(-1);
        return N;
    }

    public Vector scale(double d) {
        get_head().scale(d);
        return this;
    }

    @Override
    public boolean equals(Object obj) {
        //vectors are equal if the have the same length
        //and the same direction therefor:
        if (obj instanceof Vector) {
            if (((Vector) obj).normalize() != get_head()) {
                return;
            }


        }

        }


        return super.equals();
    }

    @Override
    public String toString() {
        return String.format("(0,0,0)->%s", super.toString());
    }



}//end of Vector