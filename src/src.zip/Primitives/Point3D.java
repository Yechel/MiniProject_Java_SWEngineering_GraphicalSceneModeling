package Primitives;

public class Point3D extends Point2D {
    private Coordinate _z;

    //getter
    public Coordinate get_z() {
        return _z;
    }

    //setter
    public void set_z(Coordinate _z) {
        this._z = new Coordinate(_z.get_coordinate());
    }

    //Ctors
    public Point3D() {
        set_x(new Coordinate());
        set_y(new Coordinate());
        set_z(new Coordinate());
    }

    public Point3D(Point3D head) {
        set_x(head.get_x());
        set_y(head.get_y());
        set_z(head.get_z());
    }
    public Point3D(Coordinate x,Coordinate y,Coordinate z) {
        super(x,y);
        set_z(z);
    }

    public Point3D(Point2D p,Coordinate z) {
        super(p);
        set_z(z);
    }

    @Override
    public String toString() {
        return   String.format("%s,%s",super.toString(),get_z());
    }

    @Override
    public boolean equals(Object obj)  throws ExceptionInInitializerError{
        if (obj instanceof Point3D) {
            if ( super.equals(obj))
                if (get_z() == ((Point3D) obj).get_z())
                    return true;
        }

        throw new ExceptionInInitializerError("the object is not Point3D type");
    }


    public void scale(double d) {
        this.set_x(this.get_x().mult(d));
        this.set_y(this.get_y().mult(d));
        this.set_z(this.get_z().mult(d));
    }


    public boolean inSameLine(Point3D p1,Point3D p2)
    {
        if ((this.substruct(p1)).substruct(p2).length == 0)
        {
            return true;
        }
        return false;
    }
}//end of Point3D
